package com.library.controller;

import static org.junit.Assert.assertEquals;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.studentlibrary.controller.StudentController;
import com.studentlibrary.entity.Student;
import com.studentlibrary.repository.StudentRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StudentControllerTest {

	@Autowired
	private StudentController studentController;

	@MockBean
	StudentRepository studentRepository;

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void getAllStudentsTest() {
		// Student std = new Student(1L, "Sachin",9,"sachin9@gmail.com","Sports");

		Mockito.when(studentRepository.findAll())
				.thenReturn(Stream
						.of(new Student(1L, "Sachin", 9, "sachin9@gmail.com", "Sports"),
								new Student(2L, "Raja", 5, "raja5@gmail.com", "Teaching"))
						.collect(Collectors.toList()));
		assertEquals(2, studentController.getAllStudents().size());
	}

}
