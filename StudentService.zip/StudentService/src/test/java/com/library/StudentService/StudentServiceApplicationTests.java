package com.library.StudentService;

import static org.junit.Assert.assertNotNull;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.studentlibrary.entity.Student;
import com.studentlibrary.repository.StudentRepository;

@SpringBootTest
class StudentServiceApplicationTests {

	@Autowired
	private StudentRepository studentRepository;

	@Test
	public void getAllStudentsTest() {
		/*
		 * Mockito.when(studentRepository.findAll()) .thenReturn((List<Student>) Stream
		 * .of(new Student(1L, "Nick", 51, "nick007@gmail.com", "IT"), new Student(2L,
		 * "Rajat", 31, "rajat31@gmail.com", "Animation"))
		 * .collect(Collectors.toList())); assertEquals(2,
		 * studentController.getAllStudents().size());
		 */

		Student std = new Student();
		std.setStdId(1l);
		std.setStdName("Akshay");
		std.setRollNo(41);
		std.setStdEmail("akshay41@gmail.com");
		std.setStdBranch("CSE");
		studentRepository.save(std);
		assertNotNull(studentRepository.findById(1l).get());
	}

	@Test
	public void allStudentTest() {
		List<Student> stdlist = studentRepository.findAll();
		
	}

	/*
	 * @Test void contextLoads() { }
	 */

}
