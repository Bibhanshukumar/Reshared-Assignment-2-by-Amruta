package com.studentlibrary.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_library")
public class Student {

	private Long stdId;
	private String stdName;
	private int rollNo;
	private String stdEmail;
	private String stdBranch;

	public Student() {
	}

	public Student(Long stdId, String stdName, int rollNo, String stdEmail, String stdBranch) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.rollNo = rollNo;
		this.stdEmail = stdEmail;
		this.stdBranch = stdBranch;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "std_Id")
	public Long getStdId() {
		return stdId;
	}

	public void setStdId(Long stdId) {
		this.stdId = stdId;
	}

	@Column(name = "std_Name")
	public String getStdName() {
		return stdName;
	}

	public void setStdName(String stdName) {
		this.stdName = stdName;
	}

	@Column(name = "roll_No")
	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	@Column(name = "std_Email")
	public String getStdEmail() {
		return stdEmail;
	}

	public void setStdEmail(String stdEmail) {
		this.stdEmail = stdEmail;
	}

	@Column(name = "std_Branch")
	public String getStdBranch() {
		return stdBranch;
	}

	public void setStdBranch(String stdBranch) {
		this.stdBranch = stdBranch;
	}

	@Override
	public String toString() {
		return "Student [stdId=" + stdId + ", stdName=" + stdName + ", rollNo=" + rollNo + ", stdEmail=" + stdEmail
				+ ", stdBranch=" + stdBranch + "]";
	}

}
