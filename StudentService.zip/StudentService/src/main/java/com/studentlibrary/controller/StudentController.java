package com.studentlibrary.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentlibrary.entity.Student;
import com.studentlibrary.exception.ResourceNotFoundException;
import com.studentlibrary.repository.StudentRepository;

@RestController
@RequestMapping("/api")
public class StudentController {

	@Autowired
	private StudentRepository studentRepository;

	// get all Students
	@GetMapping("/students")
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	// get Students by id
	@GetMapping("/students/{id}")
	public Student getUserById(@PathVariable(value = "id") Long stdId) {
		return this.studentRepository.findById(stdId)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found with id :" + stdId));
	}

	// create Student
	@PostMapping("/students")
	public Student createBook(@RequestBody Student student) {
		return this.studentRepository.save(student);
	}

	// update Student
	@PutMapping("/students/{id}")
	public Student updateBook(@RequestBody Student student, @PathVariable("id") Long stdId) {
		Student existingStudent = this.studentRepository.findById(stdId)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found with id :" + stdId));

		existingStudent.setStdId(student.getStdId());
		existingStudent.setStdName(student.getStdName());
		existingStudent.setRollNo(student.getRollNo());
		existingStudent.setStdEmail(student.getStdEmail());
		existingStudent.setStdBranch(student.getStdBranch());

		return this.studentRepository.save(existingStudent);
	}

	// delete student by id
	@DeleteMapping("/students/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable("id") Long stdId) {
		Student existingStudent = this.studentRepository.findById(stdId)
				.orElseThrow(() -> new ResourceNotFoundException("Student not found with id :" + stdId));
		this.studentRepository.delete(existingStudent);
		return ResponseEntity.ok().build();
	}
}
