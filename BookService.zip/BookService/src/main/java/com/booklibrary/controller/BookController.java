package com.booklibrary.controller;

import java.util.Collections;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booklibrary.entity.Book;
import com.booklibrary.exception.ResourceNotFoundException;
import com.booklibrary.repository.BookRepository;

@RestController
@RequestMapping("/api")
public class BookController {

	@Autowired
	private BookRepository bookRepository;

	// get all Books
	@GetMapping("/books")
	public List<Book> getAllBooks() {
		return bookRepository.findAll();

	}

	// get Book by id
	@GetMapping("/books/{id}")
	public Book getUserById(@PathVariable(value = "id") int bookId) {
		return this.bookRepository.findById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found with id :" + bookId));
	}

	// create Book
	@PostMapping("/books")
	public Book createBook(@RequestBody Book book) {

		return this.bookRepository.save(book);
		// return new ResponseEntity<Book>(bookService.addbook(book),
		// HttpStatus.CREATED);
		// Book addBook = this.bookRepository.save(book);
		// return new ResponseEntity<Book>(addBook, HttpStatus.CREATED);

	}

	// update Book
	@PutMapping("/books/{id}")
	public Book updateBook(@RequestBody Book book, @PathVariable("id") int bookId) {
		Book existingBook = this.bookRepository.findById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found with id :" + bookId));
		existingBook.setBookId(book.getBookId());
		existingBook.setBookName(book.getBookName());
		existingBook.setAuthor(book.getAuthor());
		existingBook.setPrice(book.getPrice());

		return this.bookRepository.save(existingBook);
	}

	// delete book by id
	@DeleteMapping("/books/{id}")
	public ResponseEntity<Book> deleteBook(@PathVariable("id") int bookId) {
		Book existingBook = this.bookRepository.findById(bookId)
				.orElseThrow(() -> new ResourceNotFoundException("Book not found with id :" + bookId));
		this.bookRepository.delete(existingBook);
		return ResponseEntity.ok().build();
	}

//7. Sort the book details and search for them. (you are free to cho0se the search criteria)
	// search Book by subject-wise
	@GetMapping("/searchBySubject/{subject}")
	public List<Book> searchBookByName(@PathVariable(value = "subject") String bookName) {
		List<Book> bookList = this.bookRepository.findByBookName(bookName);
		return bookList;
	}

	// Sorted by Book Name
	@GetMapping("/sortedByBookName")
	public List<Book> getSortedBookName() {
		List<Book> listBook = bookRepository.findAll();
		Collections.sort(listBook, new BookSort());
		return listBook;

	}
}
