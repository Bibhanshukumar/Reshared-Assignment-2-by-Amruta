package com.booklibrary.controller;

import java.util.Comparator;

import com.booklibrary.entity.Book;

public class BookSort implements Comparator<Book> {

	@Override
	public int compare(Book arg0, Book arg1) {

		return (arg0.getBookName().compareTo(arg1.getBookName()));
	}

}
