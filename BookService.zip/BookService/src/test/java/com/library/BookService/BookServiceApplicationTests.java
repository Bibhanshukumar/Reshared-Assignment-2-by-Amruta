package com.library.BookService;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.hamcrest.collection.IsEmptyCollection;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.booklibrary.entity.Book;
import com.booklibrary.repository.BookRepository;

@SpringBootTest
class BookServiceApplicationTests {

	@Autowired
	private BookRepository bookRepository;

	@Test
	public void getAllBooksTest() {
		Book book = new Book();
		book.setBookId(1);
		book.setBookName("Java");
		book.setAuthor("James Gosling");
		book.setPrice("549");

		bookRepository.save(book);
		assertNotNull(bookRepository.findById(1).get());
	}

	public void allBookTest() {
		List<Book> bookList = bookRepository.findAll();
		//assertEquals()
	}
}
