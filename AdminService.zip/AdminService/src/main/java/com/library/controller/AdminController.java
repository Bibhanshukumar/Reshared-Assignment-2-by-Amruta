package com.library.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.library.entity.Book;
import com.library.entity.IssueBook;
import com.library.entity.Student;
import com.library.response.ResponseTemplate;
import com.library.service.AdminServiceImpl;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private RestTemplate restTemplate;

	/* =============== Student Service================= */
	/*
	 * @GetMapping("/studentlist") public List<Student> getAllStudents() {
	 * 
	 * List<Student> students =
	 * restTemplate.getForObject("http://localhost:9090/api/students", List.class);
	 * return students; }
	 */

	@PostMapping("/addAdminStudent")
	public ResponseEntity<Student> saveStudent(@RequestBody Student student) {
		return restTemplate.postForEntity("http://localhost:9090/api/students/", student, Student.class);
	}

	/*
	 * @PutMapping("/{id}") public void updateStudent(@PathVariable("id") long
	 * stdId, @RequestBody Student student) {
	 * restTemplate.put("http://localhost:9090/api/students/" + stdId, student);
	 * System.out.println("Data updated successfully"); }
	 */
	@DeleteMapping("{id}")
	public void deleteStudent(@PathVariable("id") long stdId) {
		restTemplate.delete("http://localhost:9090/api/students/" + stdId);

	}

	/* ================ Book Service ========================= */
	/*
	 * @GetMapping("/booklist") public List<Book> getAllSBooks() { List<Book> books
	 * = restTemplate.getForObject("http://localhost:8080/api/books/", List.class);
	 * return books; }
	 */

	@PostMapping("/addAdminBook")
	public ResponseEntity<Book> saveBook(@RequestBody Book book) {
		return restTemplate.postForEntity("http://localhost:8080/api/books/", book, Book.class);
	}

	/*
	 * @PutMapping("/{id}") public void updateBook(@PathVariable("id") int
	 * bookId, @RequestBody Book book) {
	 * restTemplate.put("http://localhost:8080/api/books/" + bookId, book);
	 * System.out.println("Data updated successfully"); }
	 */
	@DeleteMapping("/book/{id}")
	public void deleteBook(@PathVariable("id") int bookId) {
		restTemplate.delete("http://localhost:8080/api/books/" + bookId);
	}

	// 8. Filter books by subject.
	@GetMapping("/searchBook/{subject}")
	public List<Book> searchBook(@PathVariable("subject") String bookName) {
		// return restTemplate.getForObject("http://localhost:8080/api/searchBySubject/"
		// + bookName, List.class);
		return restTemplate.getForObject("http://localhost:8080/api/searchBySubject/" + bookName, List.class);
	}

		/* 3. Can issue them to the registered users. */

	@PostMapping("/addissuebook")
	public IssueBook saveIssueBook(@RequestBody IssueBook issueBook) {
		//System.out.println("hiiii");
		return adminService.saveIssueBook(issueBook);
		// return restTemplate.postForEntity("http://localhost:8080/api/books/", book,
		// Book.class);
	}

	@GetMapping("/getIssueBook/{id}")
	public ResponseTemplate getIssueBook(@PathVariable("id") int issueBookId){
		//System.out.println("Hellooooo");
		ResponseTemplate resp = adminService.getIssueBook(issueBookId);
       return resp;

	}


}