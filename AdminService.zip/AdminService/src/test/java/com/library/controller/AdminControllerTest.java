package com.library.controller;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.client.RestTemplate;

public class AdminControllerTest {

	@InjectMocks
	AdminController adminControler = new AdminController();

	@Mock
	RestTemplate restTemplate;

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

}
